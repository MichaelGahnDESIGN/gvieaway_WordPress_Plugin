=== MGD Giveaway ===
Contributors: michaelgahndesign
Tags: download, forms, ebook, pdf, shortcode
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 0.0.1
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

MGD Giveaway erstellt einfache Download-Formulare fuer Gratis-eBooks und PDFs.

== Description ==

Mit MGD Giveaway koennen im WordPress-Backend Formulare angelegt, Felder ergaenzt und Dateien aus der Mediathek als Download hinterlegt werden. Das Formular wird per Shortcode eingebunden. Nach erfolgreicher Anmeldung wird ein Download-Button angezeigt.

== Installation ==

1. Plugin-Ordner `mgd-giveaway` nach `wp-content/plugins/` kopieren oder ZIP hochladen.
2. Plugin aktivieren.
3. Unter `MGD Giveaway` ein Formular erstellen.
4. Shortcode wie `[mgd_giveaway id="123"]` in eine Seite einfuegen.

== Changelog ==

= 0.0.1 =
* Erste Version mit Formular-Editor, Shortcode, Download-Anzeige, SMTP/PHP-Mail-Einstellung und Credits.
