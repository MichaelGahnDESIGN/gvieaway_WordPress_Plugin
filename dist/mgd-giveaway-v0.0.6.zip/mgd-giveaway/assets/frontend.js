(function () {
    'use strict';
})();
