=== MGD Giveaway ===
Contributors: michaelgahndesign
Tags: download, forms, ebook, pdf, shortcode
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 0.0.4
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

MGD Giveaway erstellt einfache Download-Formulare fuer Gratis-eBooks und PDFs.

== Description ==

Mit MGD Giveaway koennen im WordPress-Backend Formulare angelegt, Felder ergaenzt und Dateien aus der Mediathek als Download hinterlegt werden. Das Formular wird per Shortcode eingebunden. Nach erfolgreicher Anmeldung wird ein Download-Button angezeigt.

Anmeldungen werden in der Mail-Liste gespeichert und koennen als CSV importiert oder exportiert werden. Neue Anmeldungen werden an die in den Einstellungen hinterlegte Empfaengeradresse gesendet. Ein Log-Reiter protokolliert wichtige Aktionen und bietet Suche, Filter, Export, Speicheranzeige und Leeren-Funktion.

Der Formular-Editor enthaelt Drag & Drop Feldkarten, ein Datenschutz-Element und einen integrierten Spam-Schutz mit Honeypot und Zeitpruefung.

== Installation ==

1. Plugin-Ordner `mgd-giveaway` nach `wp-content/plugins/` kopieren oder ZIP hochladen.
2. Plugin aktivieren.
3. Unter `MGD Giveaway` ein Formular erstellen.
4. Shortcode wie `[mgd_giveaway id="123"]` in eine Seite einfuegen.

== Changelog ==

= 0.0.4 =
* Formular-Editor modernisiert: Feldkarten, Element-Palette und Drag & Drop Sortierung.
* Neues Datenschutz-Element ergaenzt.
* Spam-Schutz mit Honeypot und Zeitpruefung ergaenzt.

= 0.0.3 =
* Sicherheitsverbesserungen: CSV-Formel-Schutz beim Export, CSV-Groessen- und Zeilenlimit beim Import, strengere E-Mail-Validierung.

= 0.0.2 =
* Mail-Liste mit CSV Import und Export ergaenzt.
* Benachrichtigung neuer Anmeldungen an einstellbaren Empfaenger ergaenzt.
* Log-Reiter mit Suche, Filter, Export, Speicheranzeige und Leeren-Funktion ergaenzt.
* Datenschutz-Hinweis zu lokalen Assets dokumentiert.

= 0.0.1 =
* Erste Version mit Formular-Editor, Shortcode, Download-Anzeige, SMTP/PHP-Mail-Einstellung und Credits.
